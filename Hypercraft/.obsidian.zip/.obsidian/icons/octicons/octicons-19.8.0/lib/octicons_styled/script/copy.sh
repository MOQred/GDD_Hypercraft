#!/bin/bash

cp src/__generated__/index.d.ts dist/index.d.ts
cp src/__generated__/index.js dist/index.esm.js
