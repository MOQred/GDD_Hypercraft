# feather-icons

## 4.29.1

### Patch Changes

- [#1213](https://github.com/feathericons/feather/pull/1213) [`8f0cc0e`](https://github.com/feathericons/feather/commit/8f0cc0e6667e88b7de391ccaf75820a6e57f4f13) Thanks [@colebemis](https://github.com/colebemis)! - Test [changesets](https://github.com/changesets/changesets) release
